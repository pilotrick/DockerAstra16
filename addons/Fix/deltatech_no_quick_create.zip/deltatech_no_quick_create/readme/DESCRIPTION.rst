Features:
 - disable quick_create
