Features:
 - Show payments from invoice
