# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
from . import inherited_res_company
from . import inherited_stock_config_settings

from . import inherited_product_product
from . import inherited_res_users


