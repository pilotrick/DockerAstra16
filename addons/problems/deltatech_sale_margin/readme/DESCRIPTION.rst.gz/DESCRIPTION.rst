Features:
 - New technical access group for display margin and purchase price in sale order
 - New technical access group to prevent changing price in sale order
 - New technical access group to allow sale price  below the purchase price
 - Warning/Error on sale order if sale price is below the purchase price



sale.check_price_website - parmanetru pentru verificare pret pentru comenzile de pe website
