When a picking is created out of a procurement evaluation (from an
orderpoint, MTO,...) the calendar is considered in the computation of the
expected date of the picking and moves. For example, if it takes 1 day to
execute a stock transfer from another warehouse and it is Monday, the picking
to resupply will be created with expected start date on the previous Friday,
if the warehouse operates under a Mo-Fri working calendar.
